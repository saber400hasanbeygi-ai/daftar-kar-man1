package com.decoart.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String id = i.getStringExtra("id"), customer = i.getStringExtra("customer");
        if (customer == null || customer.trim().isEmpty()) customer = "مشتری";
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel("decoart_appointments", "یادآوری نوبت‌ها", NotificationManager.IMPORTANCE_HIGH));
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification n = new NotificationCompat.Builder(c, "decoart_appointments")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("یادآوری نوبت دکوآرت")
            .setContentText("امروز نوبت مشتری " + customer + " است")
            .setStyle(new NotificationCompat.BigTextStyle().bigText("امروز نوبت مشتری " + customer + " است"))
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true).setContentIntent(pi).build();
        nm.notify(id == null ? (int)System.currentTimeMillis() : (id.hashCode() & 0x7fffffff), n);
        if (id != null) c.getSharedPreferences("decoart_alarms", Context.MODE_PRIVATE).edit().remove(id).remove(id + "_time").apply();
    }
}
