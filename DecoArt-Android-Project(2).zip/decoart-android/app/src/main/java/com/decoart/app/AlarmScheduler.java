package com.decoart.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmScheduler {
    static PendingIntent pending(Context c, String id, String customer, long at) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("id", id); i.putExtra("customer", customer);
        int request = id.hashCode() & 0x7fffffff;
        return PendingIntent.getBroadcast(c, request, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context c, String id, String customer, long at) {
        if (at <= System.currentTimeMillis()) { cancel(c, id); return; }
        c.getSharedPreferences("decoart_alarms", Context.MODE_PRIVATE).edit().putString(id, customer).putLong(id + "_time", at).apply();
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(c, id, customer, at);
        if (Build.VERSION.SDK_INT >= 23) {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
    }
    public static void cancel(Context c, String id) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pending(c, id, "", 0));
        c.getSharedPreferences("decoart_alarms", Context.MODE_PRIVATE).edit().remove(id).remove(id + "_time").apply();
    }
    public static void restore(Context c) {
        android.content.SharedPreferences p = c.getSharedPreferences("decoart_alarms", Context.MODE_PRIVATE);
        for (String k : p.getAll().keySet()) if (!k.endsWith("_time") && p.contains(k + "_time")) {
            long t = p.getLong(k + "_time", 0); if (t > System.currentTimeMillis()) schedule(c, k, p.getString(k, "مشتری"), t);
        }
    }
}
